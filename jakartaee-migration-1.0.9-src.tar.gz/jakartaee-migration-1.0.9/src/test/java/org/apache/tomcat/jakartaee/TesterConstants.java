package org.apache.tomcat.jakartaee;

public class TesterConstants {

    public static final String JAVA_PRESENT_DOT = "javax.servlet.CommonGatewayInterface";
    public static final String JAVA_PRESENT_PATH = "javax/servlet/CommonGatewayInterface";
    public static final String JAVA_NOT_PRESENT_DOT = "javax.servlet.DoesNotExist";
    public static final String JAVA_NOT_PRESENT_PATH = "javax/servlet/DoesNotExist";
}
